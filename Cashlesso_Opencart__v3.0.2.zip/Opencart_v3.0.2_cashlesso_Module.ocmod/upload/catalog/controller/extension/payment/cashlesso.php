<?php
class ControllerExtensionPaymentCashlesso extends Controller {
	
	public function index()
	{
		$this->load->model('checkout/order');	
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		$this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $this->config->get('config_order_status_id'), "Default order status before payment.", false);
		
		$data=$this->process_cashlesso();
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . 'extension/payment/cashlesso_main')) {
			return $this->load->view($this->config->get('config_template') . 'extension/payment/cashlesso_main', $data);	
		} else {
			return $this->load->view('extension/payment/cashlesso_main', $data);
		}		
		
	}

	private function process_cashlesso() {	
    	$data['button_confirm'] = $this->language->get('button_confirm');
		$this->load->model('checkout/order');
		$this->language->load('extension/payment/cashlesso');
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		
		///////////////////////////Start cashlesso Vital  Information /////////////////////////////////
		
		if($this->config->get('payment_cashlesso_module')=='Sandbox')
			$data['action'] = 'https://uat.cashlesso.com/pgui/jsp/paymentrequest';
		else
		    $data['action'] = 'https://www.cashlesso.com/pgui/jsp/paymentrequest';
			
		
		if($this->config->get('payment_cashlesso_currency') == "INR"){
 		   $CURRENCY_CODE = "356";
 		}
		elseif($this->config->get('payment_cashlesso_currency') == "USD"){
		    $CURRENCY_CODE = "840";
		}
		elseif ($this->config->get('payment_cashlesso_currency') == "GBP") {
		    $CURRENCY_CODE = "826";
		}
		elseif ($this->config->get('payment_cashlesso_currency') == "EUR") {
		    $CURRENCY_CODE = "978";
		}else{
		    $CURRENCY_CODE = "356";
		}

		$AMOUNT = (int)$order_info['total']*100;
		$txnid = $this->session->data['order_id'];
		$salt = $this->config->get('payment_cashlesso_salt');

		$data['PAY_ID'] = $this->config->get('payment_cashlesso_key');
		$data['ORDER_ID'] = $txnid;
		$data['AMOUNT'] = $AMOUNT;
		$data['PRODUCT_DESC'] = 'opencart_products_information';
		$data['CUST_SHIP_NAME'] = $order_info['payment_firstname']."_".$order_info['payment_lastname'];
		$data['CUST_SHIP_ZIP'] = $order_info['payment_postcode'];
		$data['CUST_EMAIL'] = $order_info['email'];
		$data['CUST_SHIP_PHONE'] = $order_info['telephone'];
		$data['CUST_SHIP_STREET_ADDRESS1'] = $order_info['payment_address_1'];
		$data['CUST_SHIP_CITY'] = $order_info['payment_city'];
		$data['CUST_SHIP_COUNTRY'] = $order_info['payment_country'];
		$data['CURRENCY_CODE'] = $CURRENCY_CODE;
		$data['CUST_ID'] = 'CUSTID'.$txnid.rand(10,100000);
		$data['RETURN_URL'] = $this->url->link('extension/payment/cashlesso/callback_cashlesso');

		
		foreach ($data as $key => $value) {
		$requestParamsJoined[] = "$key=$value";
         }
		
		    sort($requestParamsJoined);
		    $merchant_data_string = implode('~', $requestParamsJoined);
		    $format_Data_string = $merchant_data_string . $salt;
		    $hashData_uf = hash('sha256', $format_Data_string);
		    $hashData = strtoupper($hashData_uf);
			$data['HASH'] = $hashData;

					/////////////End cashlesso Vital  Information /////////////////////////////////
		return $data;		
	}

			
	public function callback_cashlesso() {
		 
		$salt = $salt = $this->config->get('payment_cashlesso_salt');

		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
 		$responce_array = filter_input_array(INPUT_POST);

                foreach ($responce_array as $key => $value) {
                    if ($key == 'HASH') {
                        continue;
                    } else {
                        $responceParamsJoined[] = "$key=$value";
                    }
                }
 				//print_r($responceParamsJoined);
			    sort($responceParamsJoined);
			    $merchant_data_string = implode('~', $responceParamsJoined);
			    $format_Data_string = $merchant_data_string . $salt;
			    $hashData_uf = hash('sha256', $format_Data_string);
			    $hashData = strtoupper($hashData_uf);
			    $responce_data_hash = $hashData;

			    $receivedHash = $_REQUEST['HASH'];
			    $RESPONSE_CODE = $_REQUEST['RESPONSE_CODE'];
			    $STATUS = $_REQUEST['STATUS'];

			    if ($responce_data_hash == $receivedHash && $RESPONSE_CODE == 000 && $STATUS == "Captured") {
                      //echo "Transaction Successful";
            $this->language->load('extension/payment/cashlesso');
			$this->load->model('checkout/order');
     		$orderid = $this->request->post['ORDER_ID'];
			$order_info = $this->model_checkout_order->getOrder($orderid);
			
			$data['title'] = sprintf($this->language->get('heading_title'), $order_info['payment_method']);

			if (!isset($this->request->server['HTTPS']) || ($this->request->server['HTTPS'] != 'on')) {
				$data['base'] = HTTP_SERVER;
			} else {
				$data['base'] = HTTPS_SERVER;
			}
		
			$data['charset'] = $this->language->get('charset');
			$data['language'] = $this->language->get('code');
			$data['direction'] = $this->language->get('direction');
			$data['heading_title'] = sprintf($this->language->get('heading_title'), $order_info['payment_method']);
			$data['text_response'] = $this->language->get('text_response');
			$data['text_success'] = $this->language->get('text_success');
			$data['text_success_wait'] = sprintf($this->language->get('text_success_wait'), $this->url->link('checkout/success'));
			$data['text_failure'] = $this->language->get('text_failure');
			$data['text_cancelled'] = $this->language->get('text_cancelled');
			$data['text_cancelled_wait'] = sprintf($this->language->get('text_cancelled_wait'), $this->url->link('checkout/cart'));
			$data['text_pending'] = $this->language->get('text_pending');
			$data['text_failure_wait'] = sprintf($this->language->get('text_failure_wait'), $this->url->link('checkout/cart'));

			$order_id = $this->request->post['ORDER_ID'];

				$message = '';
				$message .= 'STATUS: ' . $this->request->post['STATUS'] . "\n";
				$message .= 'PG_REF_NUM: ' . $this->request->post['PG_REF_NUM'] . "\n";

				$this->model_checkout_order->addOrderHistory($this->request->post['ORDER_ID'], $this->config->get('payment_cashlesso_order_status_id'), $message, true);
							$data['continue'] = $this->url->link('checkout/success');
							$data['column_left'] = $this->load->controller('common/column_left');
				            $data['column_right'] = $this->load->controller('common/column_right');
				            $data['content_top'] = $this->load->controller('common/content_top');
				            $data['content_bottom'] = $this->load->controller('common/content_bottom');
				            $data['footer'] = $this->load->controller('common/footer');
				            $data['header'] = $this->load->controller('common/header');
						if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . 'extension/payment/cashlesso_success')) 									   						{			
								$this->response->setOutput($this->load->view($this->config->get('config_template') . 'extension/payment/cashlesso_success', $data));
							} else {
								$this->response->setOutput($this->load->view('extension/payment/cashlesso_success', $data));
							}


                }else{

            $this->language->load('extension/payment/cashlesso');
			$this->load->model('checkout/order');
     		$orderid = $this->request->post['ORDER_ID'];
			$order_info = $this->model_checkout_order->getOrder($orderid);
			
			$data['title'] = sprintf($this->language->get('heading_title'), $order_info['payment_method']);

			if (!isset($this->request->server['HTTPS']) || ($this->request->server['HTTPS'] != 'on')) {
				$data['base'] = HTTP_SERVER;
			} else {
				$data['base'] = HTTPS_SERVER;
			}
		
			$data['charset'] = $this->language->get('charset');
			$data['language'] = $this->language->get('code');
			$data['direction'] = $this->language->get('direction');
			$data['heading_title'] = sprintf($this->language->get('heading_title'), $order_info['payment_method']);
			$data['text_response'] = $this->language->get('text_response');
			$data['text_success'] = $this->language->get('text_success');
			$data['text_success_wait'] = sprintf($this->language->get('text_success_wait'), $this->url->link('checkout/success'));
			$data['text_failure'] = $this->language->get('text_failure');
			$data['text_cancelled'] = $this->language->get('text_cancelled');
			$data['text_cancelled_wait'] = sprintf($this->language->get('text_cancelled_wait'), $this->url->link('checkout/cart'));
			$data['text_pending'] = $this->language->get('text_pending');
			$data['text_failure_wait'] = sprintf($this->language->get('text_failure_wait'), $this->url->link('checkout/cart'));

			 

                	
			    if(isset($this->request->post['STATUS']) && $this->request->post['STATUS'] == 'Declined')
				{
					$this->model_checkout_order->addOrderHistory($this->request->post['ORDER_ID'], $this->config->get('payment_cashlesso_order_fail_status_id'),'Payment cancelled by customer...'."\n".'STATUS:'.$this->request->post['STATUS']. "\n".'PG_REF_NUM:'.$this->request->post['PG_REF_NUM'],true);	
				$data['column_left'] = $this->load->controller('common/column_left');
				$data['column_right'] = $this->load->controller('common/column_right');
				$data['content_top'] = $this->load->controller('common/content_top');
				$data['content_bottom'] = $this->load->controller('common/content_bottom');
				$data['footer'] = $this->load->controller('common/footer');
				$data['header'] = $this->load->controller('common/header');

					
				 	if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . 'extension/payment/cashlesso_cancelled')) {
						$this->response->setOutput($this->load->view($this->config->get('config_template') . 'extension/payment/cashlesso_cancelled', $data));
					} else {
				    	$this->response->setOutput($this->load->view($this->config->get('config_template') . 'extension/payment/cashlesso_cancelled', $data));
					}
				}
				elseif(isset($this->request->post['STATUS']) && $this->request->post['STATUS'] != 'Captured') {
					$this->model_checkout_order->addOrderHistory($this->request->post['ORDER_ID'], $this->config->get('payment_cashlesso_order_fail_status_id'),'Payment failed...'."\n".'STATUS:'.$this->request->post['STATUS']. "\n".'PG_REF_NUM:'.$this->request->post['PG_REF_NUM'],true);	
				$data['column_left'] = $this->load->controller('common/column_left');
				$data['column_right'] = $this->load->controller('common/column_right');
				$data['content_top'] = $this->load->controller('common/content_top');
				$data['content_bottom'] = $this->load->controller('common/content_bottom');
				$data['footer'] = $this->load->controller('common/footer');
				$data['header'] = $this->load->controller('common/header');
					
					if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . 'extension/payment/cashlesso_failure')) {
						$this->response->setOutput($this->load->view($this->config->get('config_template') . 'extension/payment/cashlesso_failure', $data));
					} else {
						$this->response->setOutput($this->load->view($this->config->get('config_template') . 'extension/payment/cashlesso_failure', $data));
					}	
				
				}

                }
            }

                

}
	
}
?>