<?php
/* Opencart Module v2.3.0.2 for Cashlesso Copyrighted file - Please do not modify/refactor/disasseble/extract any or all part content  */
// Heading
$_['heading_title']      	= 'Cashlesso Payment Gateway'; 
 

// Text 
$_['text_payment']       	= 'Extensions';

$_['text_cashlesso']      		= '<a onclick="window.open(\'https://www.cashlesso.com\');"><img src="view/image/payment/cashlesso.png" alt="Cashlesso" title="Cashlesso" style="border: 1px solid #EEEEEE;" height="25" /></a>';

$_['text_edit'] 			= 'Edit Module Parameters';

//General Settings
$_['entry_module']   		= 'Gateway Mode:';  
$_['entry_module_id'] 		='Sandbox|Production';
$_['entry_geo_zone']     	= 'Geo Zone:';
$_['entry_currency']		= 'Currency';
$_['entry_total']        	= 'Total';
$_['entry_order_status'] 	= 'Success Order Status:';
$_['entry_order_fail_status'] = 'Cancel/Fail Order Status:';
$_['entry_order_refund_status'] = 'Refund Order Status:';
$_['text_disabled']  		= 'Disabled';
$_['text_enabled']  		= 'Enabled';
$_['entry_status']       	= 'Status:';
$_['entry_sort_order']   	= 'Sort Order:';
$_['text_success']       	= 'Success: You have successfully modified Payment settings';
$_['help_total']       		= 'Order total on which this payment option to be available for checkout.';
$_['help_currency']			= 'Three-letter ISO 4217 currency code required. e.g. USD,INR,etc.';

$_['text_payment_info']     =  'Refund';
$_['text_column_amount'] 	= 'Total Amount:';
$_['text_column_order']	    = 'OrderId:';
$_['text_column_refund']    = 'Enter Amount for Refund';
$_['btn_refund'] 			= 'Refund';
$_['text_confirm_refund']  = 'Are you sure you want to refund the payment?';
$_['text_empty_refund']     = 'Please enter an amount to refund';

// Entry Cashlesso Merchant key and salt
$_['entry_merchant']     	= 'Key:';
$_['entry_salt']         	= 'Salt:';
$_['help_salt']		     	= 'Enter the Salt value provided by Cashlesso.';
$_['help_merchant']		    = 'Enter the Merchant Key provided by Cashlesso.';
$_['refund_help_merchant']  = 'Refund Amount is less than or equal to TotalAmount.';

// Error
$_['error_permission']   	= 'Warning: You do not have permission to modify payment details!';

//Error Cashlesso
$_['error_merchant']     	= 'Merchant Key Required!';
$_['error_salt']         	= 'Salt Required!';
//Error Cashlesso
$_['error_module']   		= 'Invalid Mode';
$_['error_currency']		= 'Currency code required.';
$_['error_status'] 			= 'Either Cashlesso parameters must be configured to enable this module.';

/* config keys -
cashlesso_key
cashlesso_salt

cashlesso_module
cashlesso_geo_zone_id
cashlesso_currency
cashlesso_total
cashlesso_order_status_id
cashlesso_order_fail_status_id
cashlesso_status
cashlesso_sort_order
*/

?>