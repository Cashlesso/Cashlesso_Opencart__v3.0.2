<?php

class ModelExtensionPaymentCashlesso extends Model{

	public function getOrder($order_id) {
		$qry = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order` WHERE `order_id` = '" . (int)$order_id . "' LIMIT 1");

		if ($qry->num_rows) {
			$order = $qry->row;
			return $order;
		} else {
			return false;
		}
	}

	public function getOrderNotificationLoc($order_id) {
		$qry = $this->db->query("SELECT MAX(notify) FROM `" . DB_PREFIX . "order_history` WHERE `order_id` = '" . (int)$order_id ."' LIMIT 1");

		if ($qry->num_rows) {
			$order = $qry->row;
			return $order;
		} else {
			return false;
		}
	}

	public function getOrderNotificationInsert($order,$notifyLoc,$CurrDate,$comment) {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "order_history` SET `order_id` = '" . (int)$order . "', `order_status_id` = '1', `notify` = '" . $notifyLoc . "', `comment` = '" . $comment . "', `date_added` = '" . $CurrDate. "'");
	}
	
public function getPgRefNumb($order_id) {
		$qry = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order_history` WHERE `order_id` = '" . (int)$order_id . "' AND `notify` = '1' ");

		if ($qry->num_rows) {
			$order = $qry->row;
			return $order;
		} else {
			return false;
		}
	}



public function refund($sandbox,$PAY_ID,$ORDER_ID,$AMOUNT,$TXNTYPE,$CURRENCY_CODE,$SALT,$PG_REF_NUM,$REFUND_ORDER_ID){	

	
$pg_ref = (int)$PG_REF_NUM;
 $data = array('PAY_ID' => $PAY_ID, 'ORDER_ID' => $ORDER_ID, 'AMOUNT' => $AMOUNT, 'TXNTYPE' => $TXNTYPE, 'CURRENCY_CODE' => $CURRENCY_CODE, 'PG_REF_NUM' => $pg_ref, 'REFUND_ORDER_ID' => $REFUND_ORDER_ID); 


foreach ($data as $key => $value) {
        $responceParamsJoined[] = "$key=$value";
}

 $HASH = $this->GenHash($responceParamsJoined,$SALT);

 $data["HASH"] = $HASH;

 if ($sandbox == true) {
                $url = "https://uat.cashlesso.com/pgws/transact";
            } else {
                $url = "https://www.cashlesso.com/pgws/transact";
            }


 $postvars =  json_encode($data); 
   
 $cURL = curl_init();

curl_setopt($cURL, CURLOPT_URL,$url);
curl_setopt($cURL, CURLOPT_POST, 1);
curl_setopt($cURL, CURLOPT_POSTFIELDS,$postvars);
curl_setopt($cURL, CURLOPT_RETURNTRANSFER, true);
curl_setopt($cURL, CURLOPT_HTTPHEADER, array(                                                                          
    'Content-Type: application/json',                                                                                
    'Content-Length: ' . strlen($postvars))                                                                       
);

$server_output = curl_exec($cURL);
$refundArray = json_decode($server_output, true);
curl_close ($cURL);
return $refundArray;

}

public function GenHash($data, $SALT){

	sort($data);
    $merchant_data_string = implode('~', $data);
    $format_Data_string = $merchant_data_string . $SALT;
    $hashData_uf = hash('sha256', $format_Data_string);
    $hashData = strtoupper($hashData_uf);
    return $hashData;
    
}

public function addTransaction($order_id,$total){
	$this->db->query("UPDATE `" . DB_PREFIX . "order` SET `total` = '" . (int)$total . "' WHERE `order_id` = '" . (int)$order_id . "'");
}

public function addStatus($order_id,$StatusCode){
	$this->db->query("UPDATE `" . DB_PREFIX . "order` SET `order_status_id` = '" . (int)$StatusCode . "' WHERE `order_id` = '" . (int)$order_id . "'");
}




}


?>