<?php 
class ControllerExtensionPaymentCashlesso extends Controller {
	private $error = array(); 

	public function index() {
		$this->load->language('extension/payment/cashlesso');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('setting/setting');
			
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {

			$this->model_setting_setting->editSetting('payment_cashlesso', $this->request->post);				
			
			$this->session->data['success'] = $this->language->get('text_success');
			
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}

		$data['heading_title'] = $this->language->get('heading_title');
		
		$data['entry_module'] = $this->language->get('entry_module');
		$data['entry_module_id'] = $this->language->get('entry_module_id');
		$data['entry_geo_zone'] = $this->language->get('entry_geo_zone');
		$data['entry_order_status'] = $this->language->get('entry_order_status');	
		$data['entry_order_fail_status'] = $this->language->get('entry_order_fail_status');	
		$data['entry_order_refund_status'] = $this->language->get('entry_order_refund_status');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_sort_order'] = $this->language->get('entry_sort_order');
		$data['entry_currency'] = $this->language->get('entry_currency');
		$data['help_currency'] = $this->language->get('help_currency');
		
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_all_zones'] = $this->language->get('text_all_zones');		
		$data['text_edit'] = $this->language->get('text_edit');
		
		$data['entry_merchant'] = $this->language->get('entry_merchant');
		$data['entry_salt'] = $this->language->get('entry_salt');
		$data['entry_total'] = $this->language->get('entry_total');	
		
		$data['help_merchant'] = $this->language->get('help_merchant');
		$data['help_total'] = $this->language->get('help_total');
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
        $data['help_salt'] = $this->language->get('help_salt');
		$data['tab_general'] = $this->language->get('tab_general');
		
		if(!isset($this->error['error_merchant'])) $this->error['error_merchant'] ='';
		if(!isset($this->error['error_salt'])) $this->error['error_salt'] = '';
		if(!isset($this->error['error_currency'])) $this->error['error_currency'] = '';
		if(!isset($this->error['error_status'])) $this->error['error_status'] = '';
		if(!isset($this->error['error_module'])) $this->error['error_module'] = '';

 		if ($this->error) {
			$data = array_merge($data,$this->error);
		} 
		
  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true),
      		'separator' => false
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_payment'),
			'href'      => $this->url->link('extension/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true),
      		'separator' => ' :: '
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('extension/payment/cashlesso', 'user_token=' . $this->session->data['user_token'], true),
      		'separator' => ' :: '
   		);
				
		$data['action'] = $this->url->link('extension/payment/cashlesso', 'user_token=' . $this->session->data['user_token'], 'SSL');
		
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'], 'SSL');
		
		if (isset($this->request->post['payment_cashlesso_module'])) {
			$data['payment_cashlesso_module'] = $this->request->post['payment_cashlesso_module'];
		} else {
			$data['payment_cashlesso_module'] = $this->config->get('payment_cashlesso_module');
		}
		
		
		if (isset($this->request->post['payment_cashlesso_key'])) {
			$data['payment_cashlesso_key'] = $this->request->post['payment_cashlesso_key'];
		} else {
			$data['payment_cashlesso_key'] = $this->config->get('payment_cashlesso_key');
		}
		
		if (isset($this->request->post['payment_cashlesso_salt'])) {
			$data['payment_cashlesso_salt'] = $this->request->post['payment_cashlesso_salt'];
		} else {
			$data['payment_cashlesso_salt'] = $this->config->get('payment_cashlesso_salt');
		}
		
		if (isset($this->request->post['payment_cashlesso_total'])) {
			$data['payment_cashlesso_total'] = $this->request->post['payment_cashlesso_total'];
		} else {
			$data['payment_cashlesso_total'] = $this->config->get('payment_cashlesso_total'); 
		} 
		
		if (isset($this->request->post['payment_cashlesso_currency'])) {
			$data['payment_cashlesso_currency'] = $this->request->post['payment_cashlesso_currency'];
		} else {
			$data['payment_cashlesso_currency'] = $this->config->get('payment_cashlesso_currency'); 
		} 
				
		if (isset($this->request->post['payment_cashlesso_order_status_id'])) {
			$data['payment_cashlesso_order_status_id'] = $this->request->post['payment_cashlesso_order_status_id'];
		} else {
			$data['payment_cashlesso_order_status_id'] = $this->config->get('payment_cashlesso_order_status_id'); 
		} 

		if (isset($this->request->post['payment_cashlesso_order_fail_status_id'])) {
			$data['payment_cashlesso_order_fail_status_id'] = $this->request->post['payment_cashlesso_order_fail_status_id'];
		} else {
			$data['payment_cashlesso_order_fail_status_id'] = $this->config->get('payment_cashlesso_order_fail_status_id'); 
		} 
		if (isset($this->request->post['payment_cashlesso_order_refund_status_id'])) {
			$data['payment_cashlesso_order_refund_status_id'] = $this->request->post['payment_cashlesso_order_refund_status_id'];
		} else {
			$data['payment_cashlesso_order_refund_status_id'] = $this->config->get('payment_cashlesso_order_refund_status_id'); 
		} 
		
		$this->load->model('localisation/order_status');
		
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();
		
		if (isset($this->request->post['payment_cashlesso_geo_zone_id'])) {
			$data['payment_cashlesso_geo_zone_id'] = $this->request->post['payment_cashlesso_geo_zone_id'];
		} else {
			$data['payment_cashlesso_geo_zone_id'] = $this->config->get('payment_cashlesso_geo_zone_id'); 
		} 
		
		$this->load->model('localisation/geo_zone');
										
		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();
		
		if (isset($this->request->post['payment_cashlesso_status'])) {
			$data['payment_cashlesso_status'] = $this->request->post['payment_cashlesso_status'];
		} else {
			$data['payment_cashlesso_status'] = $this->config->get('payment_cashlesso_status');
		}
		
		if (isset($this->request->post['payment_cashlesso_sort_order'])) {
			$data['payment_cashlesso_sort_order'] = $this->request->post['payment_cashlesso_sort_order'];
		} else {
			$data['payment_cashlesso_sort_order'] = $this->config->get('payment_cashlesso_sort_order');
		}
        $data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

				
		$this->response->setOutput($this->load->view('extension/payment/cashlesso', $data));
	}

	private function validate() {
		$flag=false;
		
		if (!$this->user->hasPermission('modify', 'extension/payment/cashlesso')) {
			$this->error['error_warning'] = $this->language->get('error_permission');
		}
		//Cashlesso both parameters are mandatory
		if($this->request->post['payment_cashlesso_key'] || $this->request->post['payment_cashlesso_salt']) {
			if (!$this->request->post['payment_cashlesso_key']) {
				$this->error['error_merchant'] = $this->language->get('error_merchant');
			}
			
			if (!$this->request->post['payment_cashlesso_salt']) {
				$this->error['error_salt'] = $this->language->get('error_salt');
			}
		}
		if($this->request->post['payment_cashlesso_key'] && $this->request->post['payment_cashlesso_salt']) {
			$flag=true;	
		}
		
		if (!$this->request->post['payment_cashlesso_module']) {
			$this->error['error_module'] = $this->language->get('error_module');
		}
		
		if(!$this->request->post['payment_cashlesso_currency'] || strlen($this->request->post['payment_cashlesso_currency']) < 3)
		{
			$this->error['error_currency'] = $this->language->get('error_currency');
		}
		else {
			$this->request->post['payment_cashlesso_currency'] = strtoupper($this->request->post['payment_cashlesso_currency']);
		}
		
		if(!$flag && $this->request->post['payment_cashlesso_status'] == '1')
		{
			$this->error['error_status'] = $this->language->get('error_status');
		}

		return !$this->error;
	}



	public function refund(){
		$this->load->model('extension/payment/cashlesso');
		$this->load->language('extension/payment/cashlesso');
		$Sandbox = $this->config->get('payment_cashlesso_module');
		$Salt = $this->config->get('payment_cashlesso_salt');
		$PAY_ID = $this->config->get('payment_cashlesso_key');
		$ORDER_ID = $this->request->post['order_id'];
		$AMOUNT = (double)$this->request->post['refund_amount']*100;
		$CURRENCY_CODE = "356";
		$TXNTYPE = "REFUND";
		$REFUND_ORDER_ID = "Order" . rand(10,9999);

 		//logic gen order total
		$Order = $this->model_extension_payment_cashlesso->getOrder($ORDER_ID);
 		$total_amount = (double)$Order['total']*100;
		$leftAmount = $total_amount - $AMOUNT;
 		$finalAmount = (double)$leftAmount/100;

				

		//logic gen pg ref number 
	 	$OrderHistoryData = $this->model_extension_payment_cashlesso->getPgRefNumb($ORDER_ID);
	 	$OrderHistoryComment = $OrderHistoryData['comment'];
	 	$DataLocaction =  strpos( $OrderHistoryComment, 'PG_REF_NUM' ); 
	 	$locationPG_ref_num = (int)$DataLocaction+12;
	 	$PG_REF_NUM= substr($OrderHistoryComment,$locationPG_ref_num);  
		
	 	//logic for check captured in order history
	 	$Status;
		if (strpos($OrderHistoryComment, 'Captured') == true) {
    		$Status = 'Captured';
		}else{
			$Status = 'NotCaptured';
		} 



	 	if($Status == "Captured" && $total_amount>0 && $total_amount>=$AMOUNT && $AMOUNT>0){
			 
		$this->load->model('extension/payment/cashlesso');
		
	 		$result = $this->model_extension_payment_cashlesso->refund($Sandbox,$PAY_ID,$ORDER_ID,$AMOUNT,$TXNTYPE,$CURRENCY_CODE,$Salt,$PG_REF_NUM,$REFUND_ORDER_ID);
	 	
			if(isset($result['RESPONSE_CODE']) && $result['RESPONSE_CODE']==000 && isset($result['RESPONSE_CODE']) && $result['RESPONSE_MESSAGE'] == "SUCCESS"){
				
				$this->model_extension_payment_cashlesso->addTransaction($ORDER_ID,$finalAmount);
				$RefundedAmount = $result['TOTAL_AMOUNT'];

				$covAmount = $RefundedAmount/100;
				$formatedAmount = number_format($covAmount, 2, '.', '');


				 if($total_amount == $RefundedAmount){
				 $StatusCode = 11;
				$this->model_extension_payment_cashlesso->addStatus($ORDER_ID,(int)$StatusCode);
				 }


				$cashlesso_order_notify = $this->model_extension_payment_cashlesso->getOrderNotificationLoc($ORDER_ID);
				$notifyLoc = (int)$cashlesso_order_notify+1;
				$CurrDate = date('Y-m-d H:i:s');
				$comment = "Refunded Successfully, RefundedAmount: ". $formatedAmount ." PG_REF_NUM:".$result['PG_REF_NUM'];

				 $this->model_extension_payment_cashlesso->getOrderNotificationInsert($ORDER_ID,$notifyLoc,$CurrDate,$comment);
				
				$json['error'] = false;
				$json['message'] = 'Refund successful';
				
			}else{
				
				$json['error'] = true;
				$json['message'] = 'Refund Not successful';
			}
		}else{
			if($total_amount==0){
				$StatusCode = 11;
				$this->model_extension_payment_cashlesso->addStatus($ORDER_ID,(int)$StatusCode);
				$json['error'] = true;
				$json['message'] = 'Total Amount is zero Refund Not successful';

			}else{
				
				$json['error'] = true;
				$json['message'] = 'Refund Not successful';
			}

		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));	

	}

	public function order() {
		if ($this->config->get('payment_cashlesso_status')) {
	$this->load->model('extension/payment/cashlesso');

			$order =(int) $this->request->get['order_id'];
			
		$cashlesso_order = $this->model_extension_payment_cashlesso->getOrder($order);
		$OrderHistoryData = $this->model_extension_payment_cashlesso->getPgRefNumb($order);
		$OrderHistoryComment = $OrderHistoryData['comment'];
		$DataLocaction =  strpos( $OrderHistoryComment, 'PG_REF_NUM' ); 
		$locationPG_ref_num = (int)$DataLocaction+11;
		$PG_REF_NUM= substr($OrderHistoryComment,$locationPG_ref_num); 

		//logic for check captured in order history
		$Status;
		if (strpos($OrderHistoryComment, 'Captured') == true) {
    		$Status = 'Captured';
		}else{
			$Status = 'NotCaptured';
		} 
		 


			if (!empty($cashlesso_order)&& $cashlesso_order['payment_method']== "Cashlesso" && $Status=='Captured') {

				$this->load->language('extension/payment/cashlesso');

				
				$data['text_payment_info'] = $this->language->get('text_payment_info');
				$data['text_column_order'] = $this->language->get('text_column_order');
				$data['text_column_amount'] = $this->language->get('text_column_amount');
				$data['text_column_refund'] = $this->language->get('text_column_refund');
				$data['btn_refund'] = $this->language->get('btn_refund');
				$data['text_empty_refund'] = $this->language->get('text_empty_refund');
				$data['text_confirm_refund'] = $this->language->get('text_confirm_refund');
				$data['cashlesso_order'] = $cashlesso_order;
				$data['order_id'] = $this->request->get['order_id'];
				$data['token'] = $this->request->get['user_token'];
				
				return $this->load->view('extension/payment/cashlesso_order', $data);
			}
		}
	}


}
?>